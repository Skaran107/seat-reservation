#!/usr/bin/env python3
"""
One-command on-sale stampede simulator.

Usage:
    python3 scripts/burst.py <BASE_URL> [--users N] [--hot-seat-users N]

Creates a fresh show, then fires a burst of concurrent reserve requests:
  - A "hot seat" storm: many distinct users all fight over the same single
    seat (e.g. A1). Exactly one should win (201), the rest must get a clean
    409 seat_taken.
  - A general stampede across the rest of the seats from many other users.
  - A per-user-limit prober: one user fires N parallel requests for more
    seats than the show's per_user_limit allows.
  - An idempotency prober: one user fires the same idempotency key twice
    (one retry, one with a different body) concurrently.

Prints the outcome distribution (confirmed / declined-by-reason / 5xx) and
verifies the reconciliation invariant (available + held + confirmed ==
total_seats) against GET /shows/{id} after the dust settles.
"""

import argparse
import asyncio
import collections
import sys
import time
import uuid

import httpx

HOT_SEAT = "A1"
TOTAL_SEATS = 200


def build_seat_list(n: int) -> list[str]:
    return [f"A{i}" for i in range(1, n + 1)]


async def create_show(client: httpx.AsyncClient, base_url: str) -> dict:
    seats = build_seat_list(TOTAL_SEATS)
    resp = await client.post(
        f"{base_url}/shows",
        json={
            "name": f"burst-{uuid.uuid4().hex[:8]}",
            "seats": seats,
            "price_paise": 25000,
            "per_user_limit": 4,
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


async def fire_reserve(
    client: httpx.AsyncClient,
    base_url: str,
    show_id: str,
    user_token: str,
    seats: list[str],
    idempotency_key: str,
) -> tuple[int, dict]:
    try:
        resp = await client.post(
            f"{base_url}/shows/{show_id}/reserve",
            headers={"Authorization": f"Bearer {user_token}"},
            json={"seats": seats, "idempotency_key": idempotency_key},
            timeout=60,
        )
        try:
            body = resp.json()
        except Exception:
            body = {"error": "non_json_response", "message": resp.text[:200]}
        return resp.status_code, body
    except httpx.HTTPError as e:
        return 0, {"error": "transport_error", "message": f"{type(e).__name__}: {e}"}


async def hot_seat_storm(client, base_url, show_id, n_users):
    tasks = []
    for i in range(n_users):
        token = f"hotseat-user-{i}-{uuid.uuid4().hex[:6]}"
        key = f"hotseat-{i}"
        tasks.append(fire_reserve(client, base_url, show_id, token, [HOT_SEAT], key))
    return await asyncio.gather(*tasks)


async def general_stampede(client, base_url, show_id, n_users):
    seats = build_seat_list(TOTAL_SEATS)[1:]  # exclude hot seat
    tasks = []
    for i in range(n_users):
        token = f"gen-user-{i}-{uuid.uuid4().hex[:6]}"
        # Buyers fight over a handful of "good" seats near the front to
        # create real contention, not just an even spread.
        pick = seats[i % 30]
        key = f"gen-{i}"
        tasks.append(fire_reserve(client, base_url, show_id, token, [pick], key))
    return await asyncio.gather(*tasks)


async def per_user_limit_probe(client, base_url, show_id, seats_pool):
    token = f"limit-user-{uuid.uuid4().hex[:6]}"
    tasks = []
    for i, seat in enumerate(seats_pool[:10]):
        key = f"limit-probe-{i}"
        tasks.append(fire_reserve(client, base_url, show_id, token, [seat], key))
    return await asyncio.gather(*tasks)


async def idempotency_probe(client, base_url, show_id, seat_a, seat_b):
    token = f"idem-user-{uuid.uuid4().hex[:6]}"
    key = "idem-probe-key"
    # Establish the key with a first call, then fire the same-body replay
    # and the different-body call concurrently against the now-settled
    # key. (Racing all three at once is also a valid scenario - any one of
    # the three could legitimately win the INSERT race - but it makes the
    # "which specific request wins" outcome non-deterministic, which is
    # fine for the server but awkward for a repeatable smoke test.)
    first = await fire_reserve(client, base_url, show_id, token, [seat_a], key)
    rest = await asyncio.gather(
        fire_reserve(client, base_url, show_id, token, [seat_a], key),
        fire_reserve(client, base_url, show_id, token, [seat_b], key),
    )
    return [first, *rest]


def summarize(results: list[tuple[int, dict]]) -> collections.Counter:
    c = collections.Counter()
    for status, body in results:
        if status == 201:
            c["confirmed"] += 1
        elif status == 0:
            c["transport_error"] += 1
        elif 500 <= status < 600:
            c["5xx"] += 1
        elif 400 <= status < 500:
            reason = body.get("error", f"http_{status}")
            c[f"declined:{reason}"] += 1
        else:
            c[f"unexpected:{status}"] += 1
    return c


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base_url")
    parser.add_argument("--hot-seat-users", type=int, default=500)
    parser.add_argument("--general-users", type=int, default=2000)
    args = parser.parse_args()

    base_url = args.base_url.rstrip("/")

    # keepalive_expiry below uvicorn's default keep-alive timeout (5s) so
    # the client always retires idle connections first, avoiding a
    # "server disconnected without sending a response" race where httpx
    # reuses a connection uvicorn is simultaneously closing.
    limits = httpx.Limits(max_connections=4000, max_keepalive_connections=500, keepalive_expiry=2.0)
    timeout = httpx.Timeout(60.0, connect=10.0)
    async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
        print(f"Target: {base_url}")
        print("Checking health...")
        r = await client.get(f"{base_url}/healthz", timeout=15)
        print(f"  healthz: {r.status_code} {r.text}")
        r = await client.get(f"{base_url}/readyz", timeout=15)
        print(f"  readyz:  {r.status_code} {r.text}")

        print("Creating fresh show...")
        show = await create_show(client, base_url)
        show_id = show["id"]
        total_seats = show["total_seats"]
        print(f"  show_id={show_id} total_seats={total_seats}")

        print(f"\n=== Hot seat storm: {args.hot_seat_users} users vs seat {HOT_SEAT} ===")
        t0 = time.time()
        hot_results = await hot_seat_storm(client, base_url, show_id, args.hot_seat_users)
        t1 = time.time()
        hot_summary = summarize(hot_results)
        print(f"  elapsed: {t1 - t0:.2f}s")
        for k, v in hot_summary.most_common():
            print(f"  {k}: {v}")
        hot_confirmed = hot_summary["confirmed"]
        if hot_confirmed != 1:
            print(f"  ** FAIL: expected exactly 1 confirmed winner for hot seat, got {hot_confirmed} **")
        else:
            print("  OK: exactly one winner for the hot seat")

        print(f"\n=== General stampede: {args.general_users} users across {total_seats - 1} other seats ===")
        t0 = time.time()
        gen_results = await general_stampede(client, base_url, show_id, args.general_users)
        t1 = time.time()
        gen_summary = summarize(gen_results)
        print(f"  elapsed: {t1 - t0:.2f}s")
        for k, v in gen_summary.most_common():
            print(f"  {k}: {v}")
        sample_errs = [b["message"] for s, b in gen_results if s == 0][:5]
        for e in sample_errs:
            print(f"  sample transport error: {e}")

        print("\n=== Per-user limit probe: 1 user fires 10 parallel reserves on limit=4 show ===")
        limit_results = await per_user_limit_probe(client, base_url, show_id, build_seat_list(TOTAL_SEATS)[50:])
        limit_summary = summarize(limit_results)
        for k, v in limit_summary.most_common():
            print(f"  {k}: {v}")
        if limit_summary["confirmed"] != 4:
            print(f"  ** FAIL: expected exactly 4 confirmed under per_user_limit=4, got {limit_summary['confirmed']} **")
        else:
            print("  OK: per-user limit held under concurrency")

        print("\n=== Idempotency probe: same key twice (same body) + same key (different body) ===")
        seats_for_idem = build_seat_list(TOTAL_SEATS)[70:72]
        idem_results = await idempotency_probe(client, base_url, show_id, seats_for_idem[0], seats_for_idem[1])
        idem_summary = summarize(idem_results)
        for k, v in idem_summary.most_common():
            print(f"  {k}: {v}")
        # The first call and its same-body replay must resolve to ONE
        # underlying reservation_id, even though both may return HTTP 201.
        # The different-body call against the same (now-settled) key must 409.
        confirmed_ids = {
            body.get("reservation_id") for status, body in idem_results[:2] if status == 201
        }
        diff_body_status = idem_results[2][0]
        if len(confirmed_ids) == 1 and diff_body_status == 409:
            print(f"  OK: same-key/same-body pair shares reservation_id {confirmed_ids}, different body got 409")
        else:
            print(
                f"  ** FAIL: expected same-key/same-body pair to share one reservation_id "
                f"(got {confirmed_ids}) and different-body call to 409 (got {diff_body_status}) **"
            )

        all_results = hot_results + gen_results + limit_results + idem_results
        overall = summarize(all_results)
        five_xx = overall["5xx"] + overall["transport_error"]

        print("\n=== Overall outcome distribution ===")
        for k, v in overall.most_common():
            print(f"  {k}: {v}")
        print(f"\n  Total requests fired: {len(all_results)}")
        print(f"  5xx / transport errors: {five_xx}")
        if five_xx == 0:
            print("  OK: zero 5xx across the whole burst")
        else:
            print("  ** FAIL: non-zero 5xx/transport errors **")

        print("\n=== Reconciliation ===")
        r = await client.get(f"{base_url}/shows/{show_id}", timeout=30)
        final_show = r.json()
        counts = final_show["counts"]
        computed_total = counts["available"] + counts["held"] + counts["confirmed"]
        print(f"  available={counts['available']} held={counts['held']} confirmed={counts['confirmed']}")
        print(f"  sum={computed_total} total_seats={final_show['total_seats']}")
        if computed_total == final_show["total_seats"]:
            print("  OK: reconciliation invariant holds")
        else:
            print("  ** FAIL: reconciliation invariant VIOLATED **")
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
