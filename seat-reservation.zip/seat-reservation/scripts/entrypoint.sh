#!/bin/sh
set -e

echo "Applying schema..."
python -c "
import asyncio, asyncpg, os

async def main():
    url = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/seatres')
    conn = await asyncpg.connect(url)
    await conn.execute('CREATE EXTENSION IF NOT EXISTS pgcrypto')
    with open('schema.sql') as f:
        await conn.execute(f.read())
    await conn.close()

asyncio.run(main())
"

echo "Starting server..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 \
    --workers "${WEB_CONCURRENCY:-1}" \
    --backlog 4096 \
    --limit-concurrency 5000
