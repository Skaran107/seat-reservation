#!/bin/sh
# One-command on-sale stampede: ./scripts/burst.sh <BASE_URL>
set -e
BASE_URL="${1:-http://localhost:8000}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$SCRIPT_DIR/burst.py" "$BASE_URL" "${@:2}"
