-- Seat Reservation at Scale - schema
-- All money is integer paise. All seat-claim decisions are atomic conditional
-- UPDATEs or unique-constraint-guarded INSERTs - never read-then-write.

CREATE TABLE IF NOT EXISTS shows (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL,
    price_paise     BIGINT NOT NULL CHECK (price_paise >= 0),
    per_user_limit  INT NOT NULL DEFAULT 4,
    hold_ttl_seconds INT NOT NULL DEFAULT 90,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS seats (
    show_id     UUID NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
    seat_no     TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'available'
                    CHECK (status IN ('available', 'held', 'confirmed')),
    held_by     UUID,
    confirmed_by UUID,
    reservation_id UUID,
    expires_at  TIMESTAMPTZ,
    PRIMARY KEY (show_id, seat_no)
);

CREATE INDEX IF NOT EXISTS idx_seats_show_status ON seats(show_id, status);
CREATE INDEX IF NOT EXISTS idx_seats_expires ON seats(expires_at) WHERE status = 'held';

CREATE TABLE IF NOT EXISTS reservations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    show_id         UUID NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
    user_id         UUID NOT NULL,
    seats           TEXT[] NOT NULL,
    amount_paise    BIGINT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'held'
                        CHECK (status IN ('held', 'confirmed', 'cancelled', 'expired')),
    expires_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reservations_show_user ON reservations(show_id, user_id);

-- Per-(user,show) active seat counter, updated atomically alongside seat
-- claims within the same transaction - this is what makes the per-user
-- limit race-free instead of a racy COUNT(*).
CREATE TABLE IF NOT EXISTS user_show_counters (
    show_id     UUID NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL,
    held_count  INT NOT NULL DEFAULT 0,
    PRIMARY KEY (show_id, user_id)
);

-- Idempotency: unique (user_id, idempotency_key). The atomic INSERT ... ON
-- CONFLICT DO NOTHING is the exactly-once gate; a losing INSERT means a
-- concurrent/retried request, resolved by comparing request_hash.
CREATE TABLE IF NOT EXISTS idempotency_keys (
    user_id         UUID NOT NULL,
    idempotency_key TEXT NOT NULL,
    request_hash    TEXT NOT NULL,
    reservation_id  UUID,
    response_body   JSONB,
    response_status INT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, idempotency_key)
);
