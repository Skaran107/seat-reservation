# Seat Reservation at Scale

A JSON HTTP API that sells assigned seats for a show, correctly under
heavy concurrent load: no seat is ever double-sold, no user exceeds their
per-show seat limit, and idempotency keys make retries safe.

See [WRITEUP.md](WRITEUP.md) for the design rationale (atomicity
mechanism, idempotency, holds/expiry, consistency trade-offs,
observability, AI usage disclosure).

## Stack

- Python 3.12 + FastAPI + asyncpg (raw SQL, no ORM)
- PostgreSQL (row-level locking + unique constraints are the whole
  correctness mechanism — see WRITEUP.md)
- Prometheus client for metrics, structured JSON logs

## Running locally

```bash
docker compose up -d --build
curl localhost:8000/healthz
curl localhost:8000/readyz
```

This starts Postgres and the API, applies `schema.sql` automatically on
container start, and serves the API on `http://localhost:8000`.

## API

All identity comes from the `Authorization: Bearer <token>` header — never
from the request body. Any token string is accepted (no separate
login/signup flow for this exercise); the same token always maps to the
same user.

### Create a show (admin)

```
POST /shows
{ "name": "friday-night", "seats": ["A1","A2","A3"], "price_paise": 25000, "per_user_limit": 4 }
```

### Reserve seat(s)

```
POST /shows/{id}/reserve
Authorization: Bearer <token>
{ "seats": ["A12"], "idempotency_key": "..." }
```

Behavior:
- **All-or-nothing**: if any requested seat is unavailable, the whole
  request is declined with `409 seat_taken` — no partial holds.
- **Idempotency**: same `(user, idempotency_key)` replays the original
  response. Same key + different seat list → `409 idempotent_conflict`.
- **Per-user limit**: declines with `409 per_user_limit` if the user would
  exceed `per_user_limit` confirmed seats on this show (checked
  transactionally, race-free).
- Success → `201` with the reservation. Declines are always `4xx`, never
  `5xx`.

### Cancel a reservation (owner only)

```
POST /reservations/{id}/cancel
Authorization: Bearer <token>
```

Releases the seats back to `available`. Only the reservation's owner may
cancel; anyone else gets `403`.

### Show state

```
GET /shows/{id}
```

Returns per-seat status and counts. `available + held + confirmed ==
total_seats` always holds (there is no time-boxed hold state in this
implementation — see WRITEUP.md for why — so `held` is always 0, kept in
the schema/response for forward-compatibility with that model).

### Health & metrics

- `GET /healthz` — liveness, always 200 once the process is up.
- `GET /readyz` — readiness; runs `SELECT 1` against Postgres and returns
  `503` if the DB is unreachable (fails closed).
- `GET /metrics` — Prometheus exposition format:
  - `reservations_confirmed_total{show_id}` (counter)
  - `reservations_declined_total{reason}` (counter; reasons: `seat_taken`,
    `per_user_limit`, `idempotent_conflict`, `idempotent_replay`,
    `idempotent_in_progress`, `not_found`, `validation_error`)
  - `reservations_cancelled_total` (counter)
  - `seats_available{show_id}` / `seats_held{show_id}` /
    `seats_confirmed{show_id}` (gauges, refreshed on each `/metrics` scrape
    from the DB so they always reconcile with `GET /shows/{id}`)
  - `http_request_duration_seconds{method,path,status}` (histogram)

Run with a single Uvicorn worker (`WEB_CONCURRENCY=1`, the default in
`docker-compose.yml`) so these in-process Prometheus counters stay
accurate — see WRITEUP.md's observability section for why multi-worker
would need `prometheus_client`'s multiprocess mode instead.

### Logs

Structured JSON logs to stdout, one line per request, with a
`request_id` (from the incoming `X-Request-Id` header if present,
otherwise generated) echoed back in the `X-Request-Id` response header —
so a client-reported failure can be grepped straight out of the logs.

## Burst test (one command)

```bash
./scripts/burst.sh http://localhost:8000
# or, to control load:
python3 scripts/burst.py http://localhost:8000 --hot-seat-users 500 --general-users 2000
```

This creates a fresh 200-seat show and fires, concurrently:

1. A **hot-seat storm**: N distinct users all fight over the single seat
   `A1`. Exactly one must get `201`; the rest get a clean `409
   seat_taken`.
2. A **general stampede**: many users across the remaining seats,
   clustered on the first 30 to guarantee real contention, not just an
   even spread.
3. A **per-user-limit probe**: one user fires 10 parallel reserves on a
   `per_user_limit=4` show — expects exactly 4 confirmed.
4. An **idempotency probe**: the same user fires the same idempotency key
   twice with the same body (expects both calls to resolve to one shared
   `reservation_id` — a replay, not a double booking) plus once more with
   a different body on the same key (expects `409 idempotent_conflict`).

It prints the full outcome distribution (confirmed / declined-by-reason /
5xx / transport errors) and then calls `GET /shows/{id}` to verify the
reconciliation invariant (`available + held + confirmed == total_seats`)
holds exactly, to the unit.

Requires `pip install httpx` (already in `requirements.txt`).

## Deploying to Fly.io

```bash
fly launch --no-deploy        # creates/links the app, do not let it overwrite Dockerfile
fly postgres create           # or point DATABASE_URL at any managed Postgres
fly postgres attach <pg-app-name>   # wires DATABASE_URL as a secret automatically
cp fly.toml.example fly.toml  # edit `app` to match your fly app name
fly deploy
fly status
curl https://<your-app>.fly.dev/healthz
```

`scripts/entrypoint.sh` applies `schema.sql` on every boot (idempotent —
`CREATE TABLE IF NOT EXISTS`), so a fresh Postgres is initialized
automatically on first deploy.

## Running against the deployed URL

```bash
./scripts/burst.sh https://<your-deployed-url>
```

## Project layout

```
app/
  main.py        FastAPI app, routes, health/metrics endpoints
  domain.py       Core reservation logic — all atomic transactions live here
  db.py           asyncpg pool management
  auth.py         Bearer-token -> user_id derivation
  schemas.py      Pydantic request/response models
  metrics.py      Prometheus metric definitions
  logging_config.py  Structured JSON logging setup
schema.sql        Postgres schema (seats, reservations, idempotency_keys, counters)
scripts/
  burst.py/.sh    One-command on-sale stampede load test
  entrypoint.sh   Applies schema.sql then starts uvicorn
Dockerfile
docker-compose.yml
WRITEUP.md
```
