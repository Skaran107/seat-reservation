# WRITEUP

## The atomic decision

Every seat-state change is a single SQL statement guarded by current
state, executed inside one Postgres transaction — never a
read-then-decide-then-write round trip from the application.

**Single seat, conceptually:**

```sql
UPDATE seats SET status = 'confirmed', ...
WHERE show_id = $1 AND seat_no = $2 AND status = 'available'
```

If this affects 0 rows, the seat was already taken — a clean decline, not
a retry loop. There is no window between "check" and "write" because
there is no separate check: the `WHERE status = 'available'` clause *is*
the check, evaluated atomically by Postgres's own MVCC/row-lock machinery
as part of the write.

**Multi-seat requests** (`app/domain.py:reserve_seats`) extend this with
explicit row locks instead of relying on a single UPDATE's WHERE clause,
because we need to look at *all* requested seats together before
deciding all-or-nothing:

```sql
SELECT seat_no, status FROM seats
WHERE show_id = $1 AND seat_no = ANY($2)
ORDER BY seat_no
FOR UPDATE
```

Two things make this race-free:

1. `FOR UPDATE` takes row locks, so a second transaction requesting an
   overlapping seat set blocks until the first commits or rolls back —
   there's no gap for both to read "available" and both proceed.
2. **Rows are locked in sorted seat-number order**, always. This is the
   deadlock-avoidance mechanism for multi-seat requests: if two
   transactions both want `{A1, A2}` but in different request order, they
   still acquire locks `A1` then `A2` — same order — so they queue behind
   each other instead of each holding one and waiting on the other
   (classic deadlock). Without the sort, request `["A2","A1"]` racing
   request `["A1","A2"]` could deadlock under load; Postgres would detect
   and abort one with an error, which we'd rather never surface to a
   buyer as a confusing 5xx.

After the lock is held, we re-check each row's `status` in-process; if
any requested seat isn't `available`, the whole request declines
(`409 seat_taken`) and nothing is written — **all-or-nothing**, not
best-effort partial fulfillment. We chose all-or-nothing over
best-effort because it's the behavior a buyer actually wants ("give me
these two seats together or don't bother") and because best-effort
multiplies the decline-reason space (partial success isn't really success
or failure) in a way that complicates both the client contract and the
metrics/observability story for not much real benefit in a seat-booking
domain.

The per-user limit is enforced the same way, not via a racy
`SELECT count(*) FROM reservations WHERE user_id = ... AND status =
'confirmed'`: there's a dedicated `user_show_counters(show_id, user_id,
held_count)` row, upserted and then locked with `FOR UPDATE` inside the
*same* transaction as the seat claim, incremented only if the post-claim
total would stay `<= per_user_limit`. Locking this row means two
concurrent requests from the same user serialize on their own counter,
so "fire 10 parallel reserves on a limit=4 show" can never land more than
4 — the 5th onward sees the counter already at 4 (because the previous
ones committed and released the lock before it) and declines cleanly.

## Idempotency

Stored in its own `idempotency_keys` table, keyed by
`(user_id, idempotency_key)` — a `PRIMARY KEY`, i.e. a genuine unique
constraint, not an application-level check. The exactly-once decision is:

```sql
INSERT INTO idempotency_keys (user_id, idempotency_key, request_hash)
VALUES ($1, $2, $3)
ON CONFLICT (user_id, idempotency_key) DO NOTHING
RETURNING user_id
```

- If this INSERT returns a row, **this request is the one that gets to
  perform the seat claim** — everyone else racing the same key blocks on
  the row lock, then loses the insert.
- If it returns nothing, we read back the stored `request_hash` and
  compare it (SHA-256 over `{show_id, user_id, sorted(seats)}`) to this
  request's hash:
  - **Same hash** → this is a legitimate retry. We return the *stored*
    response body verbatim (same `reservation_id`, same status code),
    without touching seats again. The burst test asserts this explicitly:
    firing the same key + same body twice concurrently must yield exactly
    one underlying `reservation_id`, even though both calls may observe
    HTTP 201.
  - **Different hash** → `409 idempotent_conflict`. The key was already
    spent on a different request body; we refuse to silently reinterpret
    it.
  - **Row exists but no response yet** (the winning request is still
    mid-transaction) → `409 idempotent_in_progress`. We chose not to
    block the second caller indefinitely waiting on the first's row lock,
    since under a stampede that queues requests behind each other instead
    of failing fast; a client that retries will see the resolved response
    on its next attempt.

The idempotency row is updated with the final response body/status
(success or decline) in the *same transaction* as the seat decision, so
the two are always consistent — there's no scenario where the seat
commits but the idempotency record doesn't (or vice versa).

## Holds & expiry

We went with **explicit cancel only**, not time-boxed auto-expiring
holds. `POST /reserve` confirms immediately (matches the spec's example
response, which returns `"status": "confirmed"` directly), and
`POST /reservations/{id}/cancel` is the only release path, restricted to
the reservation's owner (`403` otherwise).

This was a deliberate scope cut given the time budget: a real hold model
(seat goes `held` with `expires_at`, something sweeps expired holds back
to `available`, and a separate confirm/pay step finalizes it) is more
faithful to how ticketing systems actually work, but it adds a second
state machine transition, a background sweeper process (or lazy
expiry-check-on-read) with its own race surface — e.g. a sweep
expiring a hold at the exact moment its owner calls confirm — for a
behavior the example response in the spec doesn't actually exercise. The
schema (`seats.status` already has a `held` value, `reservations` has a
`held` status and `expires_at` column) is left in place so adding real
holds later is a schema-compatible extension, not a rewrite — see "what's
next" below.

A cancelled reservation's seats return to `available` by the same
single-UPDATE-guarded-on-state pattern as everything else:

```sql
UPDATE seats SET status = 'available', ...
WHERE show_id = $1 AND seat_no = ANY($2) AND reservation_id = $3
```

The `AND reservation_id = $3` guard is what prevents a stale/duplicate
cancel from resurrecting a seat that's since been confirmed to someone
else: if the seat's `reservation_id` has changed (because it was
released and re-booked), this UPDATE matches zero rows.

## Consistency vs. availability under a partition

This system chooses **consistency over availability** at the only point
that matters: the seat-claim transaction. If Postgres is unreachable, we
fail the request rather than accept a reservation we can't durably and
atomically verify — there is no local/cached fallback path that could
independently decide "this seat is free," because that's exactly the
read-then-write race the whole design exists to avoid. `GET /readyz`
reflects this directly: it fails closed (`503`) when the DB is
unreachable, so a load balancer or orchestrator pulls the instance out of
rotation instead of routing stampede traffic at a node that can only
either queue forever or guess.

In practice this is a single-Postgres-instance design (as the spec
permits — "a single database is fine and encouraged"), so the
"partition" that matters most isn't a multi-region split-brain scenario
but simpler failure modes: connection pool exhaustion under extreme
concurrency, or the DB briefly unreachable during a deploy/restart. Both
are handled the same way — the request fails fast as a declined/error
response rather than silently corrupting the invariant — rather than
trying to be available-but-possibly-wrong.

## Observability — what would page me at 2am

- **`reservations_declined_total{reason="seat_taken"}` suddenly near
  100% of traffic on a show that should have inventory** — most likely a
  stuck idempotency row, a lock pileup, or (bug scenario) a seat UPDATE
  silently not committing. This is the signal that something structural
  broke, not just "the show sold out," because a sold-out show's decline
  rate approaching 100% is itself a normal, expected end state —the thing
  to watch is the *rate of change* and whether `seats_available` for that
  show has actually hit 0.
- **`seats_available + seats_held + seats_confirmed != total_seats`** for
  any show — this is the reconciliation invariant breaking, i.e. the one
  thing that must never happen. I'd want this as its own computed alert
  (scrape `/shows/{id}` or run the reconciliation query directly against
  Postgres on a timer) rather than trusting the gauges alone, since the
  gauges and the live seat count should never disagree but a bug could
  make them disagree with each other.
- **Any `5xx` at all** on `/shows/{id}/reserve` or `/reservations/{id}/cancel`
  — these two endpoints are specified to only ever produce 2xx/4xx; a
  5xx here means an unhandled exception (bad input we didn't validate,
  a DB constraint firing unexpectedly, a connection pool exhaustion
  timeout) and should page immediately, not get batched into a daily
  error-rate dashboard.
- **`/readyz` returning 503`** — DB unreachable; the instance is correctly
  failing closed, but if this persists past a few seconds during
  steady-state traffic (not a deploy), that's an incident.
- **p99 of `http_request_duration_seconds` on `/reserve` climbing** under
  load — an early warning the DB pool or lock contention is becoming the
  bottleneck before it turns into outright timeouts/5xx.

What I would *not* want to page on: individual `409` responses
(`seat_taken`, `per_user_limit`, `idempotent_conflict`) in isolation —
those are the system working as designed under contention, which is the
entire point of the hot-seat storm scenario.

## AI usage

I used Claude (this session) to **generate the full implementation**
from a design I directed, not a design handed to me and transcribed
blind — concretely:

- **Directed**: I chose the stack (Python/FastAPI/Postgres), the
  all-or-nothing semantics for multi-seat requests, the explicit-cancel
  (not auto-expiring hold) model for this submission, and the specific
  atomicity mechanism (conditional UPDATE + `FOR UPDATE` in sorted order
  + a locked per-user counter row, rather than e.g. Postgres advisory
  locks or a `SELECT ... FOR UPDATE SKIP LOCKED` queue-based approach).
  I also specified the idempotency table shape and the exactly-once
  `INSERT ... ON CONFLICT DO NOTHING` gating pattern by name.
- **AI-generated, human-reviewed**: the actual Python/SQL implementation,
  the Dockerfile/compose setup, the burst-test script's scenario
  structure, and this writeup's prose.
- **Caught during testing, not assumed correct on paste**: running the
  burst script surfaced several real things worth noting honestly:
  1. At 2,000+ concurrent connections, the stock single-worker Uvicorn +
     a 20-connection DB pool produced transport-level timeouts (not
     application 5xx) that went away once the DB pool and Postgres
     `max_connections` were raised to match the concurrency target.
  2. The idempotency probe's first assertion was *wrong*, not the
     implementation — it expected exactly one `confirmed` outcome from a
     same-key/same-body replay pair, but returning `201` on replay (per
     spec: "a retry returns the original reservation") is correct even
     though it's not a *new* confirmation. Verified by checking both
     calls shared the same `reservation_id` and the seat was only
     confirmed once in `GET /shows/{id}`, then fixed the test's assertion.
  3. The probe originally fired all 3 requests (replay ×2, conflicting
     body ×1) in one true 3-way race on the same key. That's also a
     legitimate scenario, but it makes "which one wins the key" genuinely
     non-deterministic (any of the three can win the `INSERT ... ON
     CONFLICT` race) - a real 409 `idempotent_conflict` on *both*
     same-body calls is correct if the different-body call happens to
     win. Rewrote the probe to settle the key with one call first, then
     race the replay against the conflicting body, so the test is
     deterministic without changing server behavior.
  4. An intermittent `RemoteProtocolError: Server disconnected without
     sending a response` showed up in early runs (roughly 1 in a
     thousand requests), with nothing logged server-side. Root cause:
     httpx's default `keepalive_expiry` (5s) matches uvicorn's default
     keep-alive timeout (5s), so under sustained concurrent load httpx
     could occasionally reuse a pooled connection uvicorn was
     simultaneously closing. Fixed by setting the burst client's
     `keepalive_expiry=2.0`, strictly below uvicorn's timeout, so the
     client always retires idle connections first. Confirmed fixed with
     three consecutive clean runs (zero transport errors) after the
     change - this was a client-pool-tuning issue, not a server defect,
     but it's a good example of why "zero 5xx" isn't the only thing worth
     checking: a transport-level client error can look like a server
     problem if you don't check which side actually logged it.

## What's next

- Real time-boxed holds with auto-expiry (schema already supports it) if
  a payment/confirmation step were added between hold and confirm.
- Multi-process metrics via `prometheus_client`'s multiprocess mode if
  this needs to scale horizontally past one Uvicorn worker per instance
  (right now metrics correctness depends on `WEB_CONCURRENCY=1`).
- A seat-level `SELECT ... FOR UPDATE SKIP LOCKED` queue variant for the
  absolute hottest single seat, to shed load earlier under truly extreme
  contention (tens of thousands on one seat) instead of queuing every
  loser behind the same row lock.
- Connection-level backpressure (e.g. a request queue depth limit) so the
  system degrades by shedding new requests with a `503` rather than by
  having everything queue behind the DB pool.
