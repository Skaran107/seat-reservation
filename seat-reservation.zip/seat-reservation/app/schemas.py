import uuid
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class CreateShowRequest(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    seats: list[str] = Field(min_length=1)
    price_paise: int = Field(ge=0)
    per_user_limit: int = Field(default=4, ge=1, le=1000)

    @field_validator("seats")
    @classmethod
    def seats_unique_and_nonempty(cls, v: list[str]) -> list[str]:
        if len(v) != len(set(v)):
            raise ValueError("duplicate seat numbers in show creation")
        for s in v:
            if not s or not s.strip():
                raise ValueError("seat numbers must be non-empty strings")
        return v


class ShowSeat(BaseModel):
    seat_no: str
    status: Literal["available", "held", "confirmed"]


class ShowResponse(BaseModel):
    id: uuid.UUID
    name: str
    price_paise: int
    per_user_limit: int
    total_seats: int
    seats: list[ShowSeat]
    counts: dict[str, int]


class ReserveRequest(BaseModel):
    seats: list[str] = Field(min_length=1, max_length=20)
    idempotency_key: str | None = Field(default=None, max_length=200)

    @field_validator("seats")
    @classmethod
    def seats_unique(cls, v: list[str]) -> list[str]:
        if len(v) != len(set(v)):
            raise ValueError("duplicate seats requested")
        return v


class ReservationResponse(BaseModel):
    reservation_id: uuid.UUID
    show_id: uuid.UUID
    user_id: uuid.UUID
    seats: list[str]
    amount_paise: int
    status: Literal["confirmed", "cancelled"]
