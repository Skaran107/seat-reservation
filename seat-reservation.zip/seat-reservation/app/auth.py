"""
Identity is token-derived, never taken from the request body.

For this exercise there's no external IdP: the bearer token itself IS the
user identity. We deterministically derive a stable UUID from the token
string (same token -> same user_id, always), so no login/signup flow is
needed but identity still can't be spoofed via the request body - only by
knowing someone else's token, same as any bearer-token scheme.
"""

import uuid
from fastapi import Header, HTTPException

NAMESPACE = uuid.UUID("12345678-1234-5678-1234-567812345678")


def user_id_from_token(authorization: str | None = Header(default=None)) -> uuid.UUID:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=401,
            detail={"error": "unauthorized", "message": "Missing Bearer token"},
        )
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(
            status_code=401,
            detail={"error": "unauthorized", "message": "Empty bearer token"},
        )
    return uuid.uuid5(NAMESPACE, token)
