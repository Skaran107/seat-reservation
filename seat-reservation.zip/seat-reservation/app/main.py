import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, PlainTextResponse
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from app import db
from app.auth import user_id_from_token
from app.domain import Declined, cancel_reservation, create_show, get_show, reserve_seats
from app.logging_config import configure_logging
from app.metrics import (
    http_request_duration_seconds,
    seats_available_gauge,
    seats_confirmed_gauge,
    seats_held_gauge,
)
from app.schemas import CreateShowRequest, ReserveRequest

configure_logging()
logger = logging.getLogger("app")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.init_pool()
    logger.info("startup complete", extra={"event": "startup"})
    yield
    await db.close_pool()
    logger.info("shutdown complete", extra={"event": "shutdown"})


app = FastAPI(title="Seat Reservation at Scale", lifespan=lifespan)


@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
    start = time.monotonic()
    response = None
    try:
        response = await call_next(request)
        return response
    finally:
        duration = time.monotonic() - start
        status = response.status_code if response is not None else 500
        if response is not None:
            response.headers["x-request-id"] = request_id
        http_request_duration_seconds.labels(
            method=request.method, path=request.url.path, status=str(status)
        ).observe(duration)
        logger.info(
            "request",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status": status,
                "duration_ms": round(duration * 1000, 2),
            },
        )


@app.exception_handler(Declined)
async def declined_handler(request: Request, exc: Declined):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.reason, "message": exc.message},
    )


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=400,
        content={"error": "validation_error", "message": str(exc.errors())},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("unhandled exception", extra={"path": request.url.path})
    return JSONResponse(
        status_code=500,
        content={"error": "internal_error", "message": "an unexpected error occurred"},
    )


@app.get("/healthz")
async def healthz():
    return {"status": "ok"}


@app.get("/readyz")
async def readyz():
    try:
        pool = db.get_pool()
        async with pool.acquire() as conn:
            await conn.fetchval("SELECT 1")
        return {"status": "ready"}
    except Exception as e:
        logger.warning("readiness check failed", extra={"error": str(e)})
        return JSONResponse(status_code=503, content={"status": "not_ready", "error": str(e)})


@app.get("/metrics")
async def metrics():
    try:
        pool = db.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT show_id, status, count(*) AS c
                FROM seats GROUP BY show_id, status
                """
            )
        by_show: dict[str, dict[str, int]] = {}
        for r in rows:
            by_show.setdefault(str(r["show_id"]), {})[r["status"]] = r["c"]
        for show_id, counts in by_show.items():
            seats_available_gauge.labels(show_id=show_id).set(counts.get("available", 0))
            seats_held_gauge.labels(show_id=show_id).set(counts.get("held", 0))
            seats_confirmed_gauge.labels(show_id=show_id).set(counts.get("confirmed", 0))
    except Exception as e:
        logger.warning("metrics gauge refresh failed", extra={"error": str(e)})
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/shows", status_code=201)
async def post_show(body: CreateShowRequest):
    pool = db.get_pool()
    show_id = await create_show(
        pool, body.name, body.seats, body.price_paise, body.per_user_limit
    )
    show = await get_show(pool, show_id)
    return show


@app.get("/shows/{show_id}")
async def get_show_route(show_id: uuid.UUID):
    pool = db.get_pool()
    show = await get_show(pool, show_id)
    if show is None:
        return JSONResponse(status_code=404, content={"error": "not_found", "message": "show not found"})
    return show


@app.post("/shows/{show_id}/reserve", status_code=201)
async def post_reserve(
    show_id: uuid.UUID,
    body: ReserveRequest,
    user_id: uuid.UUID = Depends(user_id_from_token),
):
    pool = db.get_pool()
    result = await reserve_seats(pool, show_id, user_id, body.seats, body.idempotency_key)
    return result


@app.post("/reservations/{reservation_id}/cancel")
async def post_cancel(
    reservation_id: uuid.UUID,
    user_id: uuid.UUID = Depends(user_id_from_token),
):
    pool = db.get_pool()
    result = await cancel_reservation(pool, reservation_id, user_id)
    return result
