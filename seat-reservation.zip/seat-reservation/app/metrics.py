from prometheus_client import Counter, Gauge, Histogram

reservations_confirmed_total = Counter(
    "reservations_confirmed_total",
    "Total number of seats successfully confirmed",
    ["show_id"],
)

reservations_declined_total = Counter(
    "reservations_declined_total",
    "Total number of declined reservation attempts, by reason",
    ["reason"],  # seat_taken | per_user_limit | idempotent_replay | idempotent_conflict | not_found | validation
)

reservations_cancelled_total = Counter(
    "reservations_cancelled_total",
    "Total number of reservations cancelled",
)

seats_available_gauge = Gauge(
    "seats_available",
    "Current number of available seats for a show",
    ["show_id"],
)

seats_held_gauge = Gauge(
    "seats_held",
    "Current number of held seats for a show",
    ["show_id"],
)

seats_confirmed_gauge = Gauge(
    "seats_confirmed",
    "Current number of confirmed seats for a show",
    ["show_id"],
)

http_request_duration_seconds = Histogram(
    "http_request_duration_seconds",
    "HTTP request latency",
    ["method", "path", "status"],
)

db_pool_in_use = Gauge(
    "db_pool_in_use_connections",
    "Connections currently checked out of the DB pool",
)
