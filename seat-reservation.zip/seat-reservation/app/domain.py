"""
Core reservation logic. Every seat-state decision happens inside a single
Postgres transaction using row locks taken in deterministic (sorted) seat
order, so concurrent requests for overlapping seat sets can never deadlock
and the "is it free / take it" decision is never split across two
round-trips.
"""

import hashlib
import json
import logging
import uuid

import asyncpg

from app.metrics import (
    reservations_cancelled_total,
    reservations_confirmed_total,
    reservations_declined_total,
)

logger = logging.getLogger("app.domain")


class Declined(Exception):
    """A clean 4xx domain decline - never surfaced as a 500."""

    def __init__(self, status_code: int, reason: str, message: str):
        self.status_code = status_code
        self.reason = reason
        self.message = message
        super().__init__(message)


def request_hash(show_id: uuid.UUID, user_id: uuid.UUID, seats: list[str]) -> str:
    payload = json.dumps(
        {"show_id": str(show_id), "user_id": str(user_id), "seats": sorted(seats)},
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).hexdigest()


async def create_show(
    pool: asyncpg.Pool,
    name: str,
    seats: list[str],
    price_paise: int,
    per_user_limit: int,
) -> uuid.UUID:
    async with pool.acquire() as conn:
        async with conn.transaction():
            show_id = await conn.fetchval(
                """
                INSERT INTO shows (name, price_paise, per_user_limit)
                VALUES ($1, $2, $3)
                RETURNING id
                """,
                name,
                price_paise,
                per_user_limit,
            )
            await conn.executemany(
                """
                INSERT INTO seats (show_id, seat_no, status)
                VALUES ($1, $2, 'available')
                """,
                [(show_id, s) for s in seats],
            )
    return show_id


async def get_show(pool: asyncpg.Pool, show_id: uuid.UUID) -> dict | None:
    async with pool.acquire() as conn:
        show = await conn.fetchrow(
            "SELECT id, name, price_paise, per_user_limit FROM shows WHERE id = $1",
            show_id,
        )
        if show is None:
            return None
        seat_rows = await conn.fetch(
            "SELECT seat_no, status FROM seats WHERE show_id = $1 ORDER BY seat_no",
            show_id,
        )
        seats = [{"seat_no": r["seat_no"], "status": r["status"]} for r in seat_rows]
        counts = {"available": 0, "held": 0, "confirmed": 0}
        for s in seats:
            counts[s["status"]] += 1
        return {
            "id": show["id"],
            "name": show["name"],
            "price_paise": show["price_paise"],
            "per_user_limit": show["per_user_limit"],
            "total_seats": len(seats),
            "seats": seats,
            "counts": counts,
        }


async def reserve_seats(
    pool: asyncpg.Pool,
    show_id: uuid.UUID,
    user_id: uuid.UUID,
    seats: list[str],
    idempotency_key: str | None,
) -> dict:
    seats_sorted = sorted(set(seats))
    req_hash = request_hash(show_id, user_id, seats_sorted)

    async with pool.acquire() as conn:
        async with conn.transaction():
            show = await conn.fetchrow(
                "SELECT price_paise, per_user_limit FROM shows WHERE id = $1 FOR SHARE",
                show_id,
            )
            if show is None:
                raise Declined(404, "not_found", "show not found")

            # Idempotency gate: the atomic INSERT ... ON CONFLICT DO NOTHING
            # is the exactly-once decision. Only the request that wins the
            # insert gets to perform the seat claim; everyone else (replays
            # or racing duplicates) reads back whatever the winner recorded.
            if idempotency_key:
                inserted = await conn.fetchrow(
                    """
                    INSERT INTO idempotency_keys (user_id, idempotency_key, request_hash)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (user_id, idempotency_key) DO NOTHING
                    RETURNING user_id
                    """,
                    user_id,
                    idempotency_key,
                    req_hash,
                )
                if inserted is None:
                    existing = await conn.fetchrow(
                        """
                        SELECT request_hash, reservation_id, response_body, response_status
                        FROM idempotency_keys
                        WHERE user_id = $1 AND idempotency_key = $2
                        """,
                        user_id,
                        idempotency_key,
                    )
                    if existing["request_hash"] != req_hash:
                        reservations_declined_total.labels(reason="idempotent_conflict").inc()
                        raise Declined(
                            409,
                            "idempotent_conflict",
                            "idempotency key already used with a different request body",
                        )
                    if existing["response_body"] is not None:
                        reservations_declined_total.labels(reason="idempotent_replay").inc()
                        body = json.loads(existing["response_body"])
                        if existing["response_status"] >= 400:
                            raise Declined(
                                existing["response_status"],
                                body.get("reason", "declined"),
                                body.get("message", "declined"),
                            )
                        return body
                    # Another concurrent request holding this same key is
                    # still mid-transaction (row-locked); treat as conflict
                    # rather than blocking indefinitely.
                    raise Declined(
                        409,
                        "idempotent_in_progress",
                        "a request with this idempotency key is already being processed",
                    )

            # Lock target seat rows in deterministic sorted order - this is
            # what makes multi-seat requests deadlock-free under contention.
            seat_rows = await conn.fetch(
                """
                SELECT seat_no, status FROM seats
                WHERE show_id = $1 AND seat_no = ANY($2::text[])
                ORDER BY seat_no
                FOR UPDATE
                """,
                show_id,
                seats_sorted,
            )
            found = {r["seat_no"] for r in seat_rows}
            missing = set(seats_sorted) - found
            unavailable = [r["seat_no"] for r in seat_rows if r["status"] != "available"]

            if missing or unavailable:
                result = await _record_decline(
                    conn, user_id, idempotency_key, "seat_taken",
                    "one or more requested seats are unavailable",
                )
                reservations_declined_total.labels(reason="seat_taken").inc()
                raise result

            # Per-user limit, enforced via a row-locked counter in the same
            # transaction as the seat claim - never a racy SELECT COUNT(*).
            # Upsert-then-lock: ensures the counter row exists, then takes a
            # row lock on it so concurrent reserve calls from the same user
            # serialize on this check instead of racing a SELECT COUNT(*).
            await conn.execute(
                """
                INSERT INTO user_show_counters (show_id, user_id, held_count)
                VALUES ($1, $2, 0)
                ON CONFLICT (show_id, user_id) DO NOTHING
                """,
                show_id,
                user_id,
            )
            current_held = await conn.fetchval(
                """
                SELECT held_count FROM user_show_counters
                WHERE show_id = $1 AND user_id = $2 FOR UPDATE
                """,
                show_id,
                user_id,
            )
            per_user_limit = show["per_user_limit"]
            if current_held + len(seats_sorted) > per_user_limit:
                raise await _record_decline(
                    conn, user_id, idempotency_key, "per_user_limit",
                    f"user would exceed per-show seat limit of {per_user_limit}",
                )

            reservation_id = uuid.uuid4()
            amount_paise = show["price_paise"] * len(seats_sorted)

            await conn.execute(
                """
                UPDATE seats SET status = 'confirmed', confirmed_by = $3, reservation_id = $4
                WHERE show_id = $1 AND seat_no = ANY($2::text[])
                """,
                show_id,
                seats_sorted,
                user_id,
                reservation_id,
            )
            await conn.execute(
                """
                INSERT INTO reservations (id, show_id, user_id, seats, amount_paise, status)
                VALUES ($1, $2, $3, $4, $5, 'confirmed')
                """,
                reservation_id,
                show_id,
                user_id,
                seats_sorted,
                amount_paise,
            )
            await conn.execute(
                """
                UPDATE user_show_counters SET held_count = held_count + $3
                WHERE show_id = $1 AND user_id = $2
                """,
                show_id,
                user_id,
                len(seats_sorted),
            )

            response_body = {
                "reservation_id": str(reservation_id),
                "show_id": str(show_id),
                "user_id": str(user_id),
                "seats": seats_sorted,
                "amount_paise": amount_paise,
                "status": "confirmed",
            }

            if idempotency_key:
                await conn.execute(
                    """
                    UPDATE idempotency_keys
                    SET reservation_id = $3, response_body = $4, response_status = 201
                    WHERE user_id = $1 AND idempotency_key = $2
                    """,
                    user_id,
                    idempotency_key,
                    reservation_id,
                    json.dumps(response_body),
                )

            reservations_confirmed_total.labels(show_id=str(show_id)).inc(len(seats_sorted))
            return response_body


async def _record_decline(
    conn: asyncpg.Connection,
    user_id: uuid.UUID,
    idempotency_key: str | None,
    reason: str,
    message: str,
) -> Declined:
    status_map = {"seat_taken": 409, "per_user_limit": 409}
    status_code = status_map.get(reason, 409)
    if idempotency_key:
        await conn.execute(
            """
            UPDATE idempotency_keys
            SET response_body = $3, response_status = $4
            WHERE user_id = $1 AND idempotency_key = $2
            """,
            user_id,
            idempotency_key,
            json.dumps({"reason": reason, "message": message}),
            status_code,
        )
    return Declined(status_code, reason, message)


async def cancel_reservation(
    pool: asyncpg.Pool, reservation_id: uuid.UUID, user_id: uuid.UUID
) -> dict:
    async with pool.acquire() as conn:
        async with conn.transaction():
            res = await conn.fetchrow(
                """
                SELECT id, show_id, user_id, seats, amount_paise, status
                FROM reservations WHERE id = $1 FOR UPDATE
                """,
                reservation_id,
            )
            if res is None:
                raise Declined(404, "not_found", "reservation not found")
            if res["user_id"] != user_id:
                raise Declined(403, "forbidden", "only the owner may cancel this reservation")
            if res["status"] != "confirmed":
                raise Declined(409, "invalid_state", f"reservation is already {res['status']}")

            await conn.execute(
                """
                UPDATE seats SET status = 'available', confirmed_by = NULL, reservation_id = NULL
                WHERE show_id = $1 AND seat_no = ANY($2::text[]) AND reservation_id = $3
                """,
                res["show_id"],
                res["seats"],
                reservation_id,
            )
            await conn.execute(
                "UPDATE reservations SET status = 'cancelled', updated_at = now() WHERE id = $1",
                reservation_id,
            )
            await conn.execute(
                """
                UPDATE user_show_counters SET held_count = GREATEST(held_count - $3, 0)
                WHERE show_id = $1 AND user_id = $2
                """,
                res["show_id"],
                user_id,
                len(res["seats"]),
            )

            reservations_cancelled_total.inc()
            return {
                "reservation_id": str(reservation_id),
                "show_id": str(res["show_id"]),
                "user_id": str(user_id),
                "seats": res["seats"],
                "amount_paise": res["amount_paise"],
                "status": "cancelled",
            }
